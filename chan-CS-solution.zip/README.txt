Just open index.html in a reasonably modern webbrowser. :)
